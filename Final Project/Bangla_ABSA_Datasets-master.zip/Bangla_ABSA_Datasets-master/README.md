# Bangla_ABSA_Datasets

We had collected Bangla reviews from two different domains (cricket, restaurant) and annotated it manually.
This work was the part of my master's thesis.
